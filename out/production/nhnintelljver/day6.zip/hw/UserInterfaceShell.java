package day6.hw;

public class UserInterfaceShell {
    public static void userShell(){
        System.out.println("은행 프로그램 !!!");
        System.out.println("시작!!");
    }
    public static void main(String[] args) {
        userShell();
        Bank bank = new Bank();
        for (int i = 0; i < 5; i++) {
            System.out.println( bank.openAccount(bank.getCustomers().get(i),bank.getAccounts().get(i).getBalance()).toString());
        }
    }
}
